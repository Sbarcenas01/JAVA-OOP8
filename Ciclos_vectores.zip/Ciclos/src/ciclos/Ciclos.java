package ciclos;

import java.util.Scanner;


public class Ciclos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*INDETERMINADOS*/
        //TIPOS DE BUCLES
        //While
        //do - While
        
        int conPrincipal = 0; // Contador para valernos de el en la condiciòn.
        
        /*Condicion que dice que mientras el contador sea menor que 11 
        ejecuta el codigo del bucle while*/
        
        while(conPrincipal < 11){ //Condiciòn 
            System.out.println(conPrincipal);//Muestra el contador
            conPrincipal++; //Se le aumenta en uno al contador cada ves que en bucle se ejecute
        }
        
        //EJERCICIO MOSTRAR LA TABLA DEL 6
        int multiplicando = 6;// Creamos variable para guardar el 6
        int numeral =  1; // el numero por el cual se va a multiplicar como variable
        int resultado; //Almacenaremos el resultado
        
        while (numeral < 10){ // While para mostrar solo hasta la tabla del 10
        numeral ++; //Aumentamos nuestro numeral para multiplicar
            System.out.println("tabla del"+ multiplicando+" * " + numeral); //Mensaje de operacion
            resultado = multiplicando * numeral; // Operacion con el numeral a el numero asignado 
            System.out.println(resultado); // Resultado
        }
        
        // EJERCICIO TODAS LAS TABLAS DEL 1 AL 10
        int multiplicando1 = 0; // Variable de la tabla a multiplicar
        int numeral1 =  1; // Numero de la tabla a multiplicar y contador al mismo tiempo
        int resultado1; // Almacenaremos el resultado
        
        while(multiplicando1 < 10){  // While para mostrar solo hasta la tabla del 10
            
            multiplicando1++; // Aumentamos en uno nuestra tabla
            
            numeral1 = 1; // Cuando empiece el proceso se reinicia a 1 la tabla 
            
            while(numeral1 < 10){  // While para mostrar solo hasta la tabla del 10
                
             numeral1++; // Aumnetmaos nuestro numeral a multiplicar
             
             resultado1 = multiplicando1 * numeral; // Operacion
             
            System.out.println("tabla del"+ multiplicando1+" * " + numeral1); // Mensaje de operacion
             
            System.out.println(resultado1); // mostramos resultado
            
            }
            
        }
        
        // Ejercicio, mostrar todos los nùmero par del 1 al 100
        
        int npar = 0; // Variable donde almacenar numero par temporal / mientras se cambia por otro
        int contador = 0; // Contador aunmentativo
        
        while(contador < 100){ // Condicion que contador sea menor que 100
        contador+=2; // Aumentamos en contador de 2 en 2
        npar += contador; // Almacenamos el numero par actual en la variable
        System.out.println("Numero pares: \n"+contador); //Mostramos el numero par actual
          
        }
          System.out.println(" y la Suma de todos es : " + npar);// fuera del bucle sumatoria de todos los numeros pares
        
          
          
          /*
        Mostrar en pantalla una serie incremental del 0 al 10. ( 0 1 2 3 .... 10)
        Mostrar en pantalla la tabla del 6.
        Ejercicio mostrar los pares del 1 al 100 
        
        */
          
          
       //do-while
       
       //CREACION DE MENU CON BUCLE DO-WHILE
        System.out.println("------------------------------------------");
         System.out.println("--------- Bienvenido a nuestro menu DO-WHILE ----------");
         
         
        Scanner sc = new Scanner(System.in); // Iniciamos nuestro objeto de tipo Scanner
        
        int opcion = 0; // Creamos una variable a evaluar por nuestro Ciclo / Bucle
       do{ //  El codigo del bucle DO-WHILE se ejecuta almenos una vez entre la sentencia do{ Codigo }while(condicion);
           System.out.println("Escoge un opcion de nuestro de sistema de peliculas porno: "); // Mensaje al usuario
           System.out.println("1- Entrar a la opcion 1 \n 2- Entrar a la opcion 2 \n 3- Entrar a la opcion 3 \n 4- Salir");
           //Menu de opciones
           opcion = sc.nextInt(); //cambiamos el valor de nuestra variable opcion que para evaluarla en base a nuestro menù
           switch(opcion){
               case 1: //Caso 1, con texto
                   System.out.println("Escogiste la opcion 1");
                   break;
           case 2: //Caso 2, con texto
                  System.out.println("Escogiste la opcion 2"); 
                   break;
           case 3: //Caso 3, con texto
                System.out.println("Escogiste la opcion 3");   
                   break;
                    case 4: // Caso vacio para que al usar la opcion salir no nos mande a Default
                   
                   break;
           default: // Opcion default si caso no es 1,2,3 o 4
                System.out.println("Escogiste una opcion fuera de rango");   
               break;
           }
       }while(opcion != 4); //Esta condicion dice que el bucle se ejecuta mientras que opcion sea diferente de "4"1
       
       /* 
          OPERADORES A RECORDAR
       
          ( != ) Operador diferente
          ( == ) Operador Igual que
          ( >= ) Mayor o igual que 
          ( <= ) Menor o igual que 
       
       */
        
        /*DETERMINADOS*/
        
        // for
        //for - each
        
        for(int i = 0;i<20 ;i+=5 ){ // Bucle For con 3 campos for(Declaracion de una variable; Condicion; Operacion){ Codigo}
        System.out.println("ciclos.Ciclos.main()"); // Mensaje a mostrar
        
        }
        
        
        
        
    }
    
}
