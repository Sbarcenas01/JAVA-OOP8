
package ciclos;

import java.util.Scanner;

/**
 *
 * @author SBarc
 */
public class Vectores {
    
    public static void main(String[] args) {
        
     String[] array = new String[10]; // Asi se crea un vector tipoDato[] nombre = new tipoDato[numero de posiciones];
        Scanner sc = new Scanner(System.in); // Creamos el Scanner
        /*
        Crea un array de 10 posiciones de números con valores pedidos por teclado.
        Muestra por consola el indice y el valor al que corresponde. Haz dos métodos, 
        uno para rellenar valores y otro para mostrar.
        */
      System.out.println("Ingrese 10 datos de texto para nuestra prueba :"); // mensaje al usuario 
        for (int i =0 ;i<array.length ;i++ ){// ciclo for con condicion menor al tamaño del array
        array[i] = sc.next(); // Pedimos el dato las veces que( i ) sea menor al tamaño del Array 
        }
        System.out.println("a continuacion vamos a mostrar los datos ingresados :");// mensaje al usuario 
        for (int i =0 ;i<array.length ;i++ ){// ciclo for con condicion menor al tamaño del array
        System.out.println(array[i]); // Mostramos el dato las veces que( i ) sea menor al tamaño del Array 
        }
        
         
       //String.toChararray   Hola String[0] = H String[1] = o 
        /*

       
        Crea un array de caracteres en base a un palabra digitada por el usuario,
        que nos permita verificar  si es un correo electronico valido
       
        */
        
        // 1 - )
        
        
        
        //Ejercicio Juanfer!
       
        String nombre = sc.next(); // creamos Scanner
        boolean valido = false; // Variable para verificar correo electronico
        char caracter = 'º'; // Caracter que debe existir una unica vez, iniciada con cualquier caracter que no sea el a evaluar
        char[] correo = nombre.toCharArray();
        
        /* Creamos Array de tipo Char[] que iniciamos con nombre.toChararray, osea va a ser de tamaño igual a la palbara que ingrese la persona*/
        
        if  (correo.length>0){// Si corre es meyor que 0 se peude empezar a validar de otro modo el boolean valido se queda falso como inicio
        for (int i = 0; i < correo.length; i++) {// for para recorrer el Array
        if(correo[i] == '@'){ // Si el caracter de la poscion ( i ) de correo es '@' 
        if(caracter !=  '@'){ // y ademas si caracter como variable es diferente de arroba 
        caracter = '@'; // se le asigana a  caracter @
        valido = true; // y se hace true 
        /* Nota peros si  vuelve a aparecer otro caracter con @ incluido la validacion no inica por que caracter no es diferente de  @ como 
        se muestra en el segundo if*/
        }else{
        valido = false; // Si no se cumple que caracter sea diferente de @ al aparecer un @  es falsa por que la palabra tendira 2 '@'
        }
        }
        }
        
        
        
        
        }
        /*Validamos y mostramos el resultado*/
        if(valido == true){
        
        System.out.println("Correo Valido");
        }else{
        
        System.err.println("Correo Invalido");
        }
        
        
        
        
        
        
       
    
    String[][] vector = new String[2][2];// matrices o vectores dentro de vectores 
    // Se inician con tipoDato[][] nombre = new tipoDato[tamaño de columnas][tamaño de filas];
    vector[0][0] = "[0,Amigos]"; // Se asignan datos por posicion
    vector[0][1] = "[0,1]";
    vector[1][0] = "[1,0]";
    vector[1][1] = "[1,1]";
    
        System.out.println(vector); // Se imprime de la manera inadecuada
        
        for (int i = 0; i < vector.length; i++) { // se hace un for que recorre las columnas miestras sean mensores que vector.lengrh
            for (int j = 0; j <vector[i].length; j++) {// se hace un for que recorre las filas miestras sean mensores que vector[i].lengrh
                
                System.out.println(vector[i][j]); // Se muestran los datos guardados
                
                
            }
        }
        
        
        /*
        
        1. Indicar la primera posición en la que aparece un elemento en una matriz de enteros.
        */
        
         int[][] vector1 = new int[2][2];
    vector1[0][0] = 1;
    vector1[0][1] = 2;
    vector1[1][0] = 3;
    vector1[1][1] = 4;
        int dato=4;
        boolean tr= false;
        for (int i= 0; i< vector1.length;i++)
            
        {
            for( int j = 0;j< vector1[i].length; j++)
            {
         if   (vector1[i][j] == dato){
         
             System.out.println("Posicion x:"+i+" Posicion y: "+ j);  
            tr = false;
            break;
         }    
                if(tr == true){
                break;
                
                }
            
          }
             
            
            
        }
        
        
        
        // EJERCICIOS DE PRACTICA EN VECTORES (No te dejo de bucles por que ya hicimos full ejemplos no lo vi neceaario)
        
        /*
        
        2. Indicar los elementos de una matriz de enteros que sean impares.
        3. Indicar la suma de los números negativos de fila par de una matriz de enteros.
        

        */
        
        
    }
    
}
